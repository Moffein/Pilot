## Pilot (BETA)

Fully functional, just needs animation polish and some skins.

[<img src="https://raw.githubusercontent.com/Moffein/Pilot/master/Art%20Assets/LobbyPreview.jpg">](https://raw.githubusercontent.com/Moffein/Pilot/master/Art%20Assets/LobbyPreview.jpg)
[<img src="https://raw.githubusercontent.com/Moffein/Pilot/master/Art%20Assets/texIconPilot.png">](https://raw.githubusercontent.com/Moffein/Pilot/master/Art%20Assets/texIconPilot.png)

## To Do

- Polish anims (a lot)
- Skins
- Polish parachute visuals
- Drone in skybox?

## Credits

- Moffein (Code)
- TimeSweeper (Anims + Unity + Code)
- dotflare (Model + Anims)
- Leaf_It (Skill Icons)

## Translation Credits

- Russian: Lecard, Kaban
- Portuguese: Kauzok