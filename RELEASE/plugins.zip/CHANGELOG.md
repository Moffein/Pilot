`0.3.2`
  - Fixed gun in emote rig.
  - Updated r2api dependencies.

`0.3.1`
  - Fixed EntityStates not being registered. This should fix most MP bugs.
  - Fixed Special projectile visuals not showing online.
  - Emote support. (Currently a bit bugged, gun position will permanently change after emotes. Fix coming later.)

`0.3.0`
  - Release