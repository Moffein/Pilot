`0.3.4`
- Fixed internal version number.

`0.3.3`
  - Fixed Parachute linerenderers lagging behind the model.
  - Cluster Fire
	- AoE is reduced at point blank (11m -> 3m), and scales up to full at 11m.

`0.3.2`
  - Fixed gun in emote rig.
  - Updated r2api dependencies.

`0.3.1`
  - Fixed EntityStates not being registered. This should fix most MP bugs.
  - Fixed Special projectile visuals not showing online.
  - Emote support. (Currently a bit bugged, gun position will permanently change after emotes. Fix coming later.)

`0.3.0`
  - Release